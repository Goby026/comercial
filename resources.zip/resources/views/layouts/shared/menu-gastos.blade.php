<li><a href="{{url('cotizacionFinal')}}"><i class="fa fa-circle-o"></i>Cierre de Cotizaciones</a></li>
<li><a href="{{url('gastos')}}"><i class="fa fa-circle-o"></i>Gastos</a></li>