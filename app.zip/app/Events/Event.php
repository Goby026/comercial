<?php

namespace appComercial\Events;

abstract class Event
{
    //
}
