<?php

namespace appComercial;

use Illuminate\Database\Eloquent\Model;

class Pipeline extends Model
{
    //
}
