<?php

namespace appComercial\Http\Controllers;

use Illuminate\Http\Request;

use appComercial\Http\Requests;

class TipoProveedorController extends Controller
{
    //
}
