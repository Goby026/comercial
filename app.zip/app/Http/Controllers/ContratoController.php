<?php

namespace appComercial\Http\Controllers;

use Illuminate\Http\Request;

use appComercial\Http\Requests;
use appComercial\Contrato;//hacemos referencia al modelo

class ContratoController extends Controller
{
    //
}
